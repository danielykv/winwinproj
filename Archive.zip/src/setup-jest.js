import $ from 'jquery';
global.$ = global.jQuery = $;